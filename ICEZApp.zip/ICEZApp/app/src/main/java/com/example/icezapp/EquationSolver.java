package com.example.icezapp;

public class EquationSolver {

	Equation eq;
	int ch;
	int x;
	int y;

	String solution;

	/**
	 * Empty constructor
	 */
	public EquationSolver() 
	{
		
	}

	/**
	 * Constructor requires equation object as a parameter
	 * Finds the type of operand in the string (Addition, Subtraction, Multiplication, and Division)
	 */
	public EquationSolver(Equation e) 
	{
		eq = e;
		ch = eq.getOperand();
		x = eq.getx();
		y = eq.gety();

		solution = " ";

			if (ch == 1) //Addition
			{
				add();
			}
			else if (ch == 2) //Subtraction
			{
				subtract();
			}
			else if (ch == 3) //Multiplication
			{
				multiply();
			}
			else if (ch == 4) //Division
			{
				divide();
			}
		
	}

	/**
	 * Gets the generated solution
	 * @return
	 */
	public String getSolution()
	{
		return solution;
	}

	/**
	 * Generates a solution for a given addition problem
	 */
	public void add()
	{
	
		//system("cls");
		//srand(time(NULL)); 
		int A = 0;
		int v = 0;
		int o = 0;
		
		
		//x = (rand() % 20) + 1;
		//y = (rand() % 20) + 1;
		
		
		solution = "You have the problem: " + x + " + " + y +". " + "\n" ;
	
		solution +="Pretend every number is made up of tally marks, every mark equals 1." +"\n"+ "\n";

		solution +="I = One." + "\n";
		solution +="II = Two." + "\n";
		solution +="IIIII = Five." + "\n";
		solution +="IIIII IIIII = Ten."+"\n"+ "\n";

		solution +="So, " + x + " will be written as ";
		while (v < x)
		{
			solution +="I";
			v++;
			
			if(v % 5 == 0)
			{
				solution += " ";
			}
		}

		solution +="\n" +" and " + y + " will be written as ";
		while (o < y)
		{
			solution +="I";
			o++;
	
			if (o % 5 == 0)
			{
				solution +=" "+ "\n";
			}
		}solution +=" " + "\n";
		
	
		A = x + y;
		solution +="Add these tallies up, and the number you find will be " + A + ", the same number you get when you add " + x + " and " + y + " together."+ "\n"+"\n";

		solution +="So that means: " + x + " + " + y + " = " + A+ "\n";
	}

	/**
	 * Generates a solution for a given subtraction problem
	 */
	void subtract()
	{
	
		//system("cls");
		//srand(time(NULL));
		int A = 0;
		int v = 0;
		int o = 0;
	
	
		//x = (rand() % 20) + 1;
		//y = (rand() % 20) + 1;
	
		if (x > y) {
			solution ="You have the problem: " + x + " - " + y + "\n";

			solution +="Pretend every number is made up of tally marks, every mark equals 1." +"\n"+ "\n" ;

			solution +="I = One."+ "\n";
			solution +="II = Two."+ "\n";
			solution +="IIIII = Five."+ "\n";
			solution +="IIIII IIIII = Ten." +"\n"+"\n";

			solution +="So, " + x + " will be written as ";
			while (v < x)
			{
				solution +="I";
				v++;
	
				if (v % 5 == 0)
				{
					solution +=" ";
				}
			}

			solution +="\n"+" and " + y + " will be written as ";
			while (o < y)
			{
				solution +="I";
				o++;
	
				if (o % 5 == 0)
				{
					solution +=" ";
				}
			} solution +=" " + "\n";
	
			A = x - y;
			solution +="Take away one tally from the larger set of tally marks for every tally there is from the smaller set of tally marks, and the number you find will be " +
					A + ", the same number you get when you subract " + y + " from " + x + "."+ "\n";

			solution +="So that means: " + x + " - " + y + " = " + A+ "\n";
		}
		else {
			solution +="You have the problem: " + y + " - " + x + "\n";

			solution +="Pretend every number is made up of tally marks, every mark equals 1."+"\n"+ "\n";

			solution +="I = One."+ "\n";
			solution +="II = Two."+ "\n";
			solution +="IIIII = Five."+ "\n";
			solution +="IIIII IIIII = Ten."+"\n"+ "\n";

			solution +="So, " + y + " will be written as ";
			while (v < y)
			{
				solution +="I";
				v++;
	
				if (v % 5 == 0)
				{
					solution +=" ";
				}
			}

			solution +="\n"+" and " + x + " will be written as ";
			while (o < x)
			{
				solution +="I";
				o++;
	
				if (o % 5 == 0)
				{
					solution +=" ";
				}
			} solution +=" "+ "\n";
	
			A = y - x;
			solution +="Take away one tally from the larger set of tally marks for every tally there is from the smaller set of tally marks, and the number you find will be " +
					A + ", the same number you get when you subract " + x + " from " + y + "."+"\n"+ "\n";

			solution +="So that means: " + y + " - " + x + " = " + A+ "\n";
		}
	}

	/**
	 * Generates a solution for a given multiplication problem
	 */
	void multiply()
	{
		//system("cls");
		//srand(time(NULL));
	

		int A = 0;
		int v = 0;
		int q = 0;
	
	
	
		//x = (rand() % 13);
		//y = (rand() % 13);
		A = x * y;
		solution ="You have the problem: " + x + " x " + y+ "\n";
		
		if (x == 1) 
		{
			solution +="When a number is being multiplied by 1, when using the methood provided,"+ "\n";
			solution +="the answer equals the number that isn't 1."+ "\n";

			solution +="Any number multiplied by 1 equals itself."+ "\n";

			solution +=x + " x " + y + " = " + A+ "\n";
		}
		
		else if (y == 1) 
		{
			solution +="When a number is being multiplied by 1, when using the methood provided,"+ "\n";
			solution +="the answer equals the number that isn't 1."+ "\n";

			solution +="Any number multiplied by 1 equals itself." + "\n" ;

			solution +=x + " x " + y + " = " + A+ "\n";
		}
		
		if (x == 0 || y == 0) 
		{
			solution +="When a number is being multiplied by 0, it automatically equals 0."+ "\n";

			solution +=x + " x " + y + " = " + A+ "\n";
		}
	
		else 
		{
			solution +="With basic multiplication, you're adding the first number to itself as meny times as how large the second number is"+ "\n";

			solution +="So, you would add " + x + " to itself " + y + " time(s)."+ "\n";

			solution +="This would be written out as: " + x+ "\n";
			while (v < y - 1)
			{
				solution += " + " + x;
				v++;
			} solution +=" "+ "\n";

			solution +="Adding up the equation above, it will equal the answer to " + x + " x " + y+ "\n";

			solution +=( x);
			while (q < y - 1)
			{
				solution +=" + " + x;
				q++;
			} solution +=" = " + A +"\n"+"\n";
			solution +=x + " x " + y + " = " + A+ "\n";
		}
		
	}

	/**
	 * Generates a solution for a given division problem
	 */
	void divide()
	{
		
		//system("cls"); 
		//srand(time(NULL));
	
		int v = 0;
		int w = 0;
		//x = (rand() % 13);
		//y = (rand() % 13);
		
		if (x * y != 0) 
		{
	
	
			if (x >= y)
			{
				solution ="You have the problem: " + x + " / " + y +". " + "\n";

				solution +=" How many times can " + y + " go into " + x + "?" + "\n";
				solution +=" Add " + y + " to itself repeatedly until it is equal to or less than " + x;
				solution +=" without going over." + "\n";
	
				int r = x;
				int o = 0;
				while (r >= y)
				{
					solution +=( y);
	
					v++;
	
					r -= y;
	
					if (r >= y)
					{
						solution +=" + ";
					}
				} o = v * y;
				solution +=" = " + o+ "\n";
				solution += y + " can go into " + x + " " + v + " time(s) without going over."+ "\n";
				if (r != 0)
				{
					solution +="Since " + o + " is still smaller than " + x + ", this tells us"+ "\n";
					solution +="there is a remainder."+ "\n";

					solution +="To find the remainder, we simply subtract " + o + " from " + x+ "\n";

					solution +=x + " - " + o + " = " + r+ "\n";

					solution +="Our answer to " + x + " / " + y + " is " + v + " with a remainder of " + r+ "\n";
					solution +=x + " / " + y + " = " + v + ", R = " + r+ "\n";
				}
				else 
				{
					solution +="Since " + o + " is equal to " + y + ", this tells us"+ "\n";
					solution +="there are no remainders."+ "\n";

					solution +="Our answer to " + x + " / " + y + " is " + v + "."+ "\n";
					solution +=x + " / " + y + " = " + v+ "\n";
				}
			} 
			
			else 
			{
				solution +="You have the problem: " + y + " / " + x+ "\n";

				solution +="How many times can " + x + " go into " + y + "?"+ "\n";
				solution +="Add " + x + " to itself repeatedly until it is equal to or less than " + y;
				solution +="without going over."+ "\n";
	
				int r = y;
				int o = 0;
				while (r >= x)
				{
					solution +=( x);
	
					v++;
	
					r -= x;
	
					if (r >= x)
					{
						solution +=( " + ");
					}
				} o = v * x;
				solution +=" = " + o+ "\n";
				solution +="n" + x + " can go into " + y + " " + v + " time(s) without going over."+ "\n";
				if (r != 0)
				{
					solution +="Since " + o + " is still smaller than " + y + ", this tells us"+ "\n";
					solution +="there is a remainder."+ "\n";

					solution +="To find the remainder, we simply subtract " + o + " from " + y+ "\n";
					solution +=y + " - " + o + " = " + r+ "\n";

					solution +="Our answer to " + y + " / " + x + " is " + v + " with a remainder of " + r+ "\n";
					solution += y + " / " + x + " = " + v + ", R = " + r+ "\n";
				}
				else
				{
					solution +="Since " + o + " is equal to " + x + ", this tells us"+ "\n";
					solution +="there are no remainders."+ "\n";

					solution +="Our answer to " + y + " / " + x + " is " + v + "."+ "\n"+"\n";
					solution +=y + " / " + x + " = " + v+ "\n";
				}
			}
		}
	
		else
		{
			if (y == 0)
			{
				solution +="You have the problem: " + x + " / " + y+ "\n";

				solution +="This problem is unabled to be solved, as anything divided by 0 is undefined, or not abled to be solved."+ "\n";
			}
			else
			{
				solution +="You have the problem: " + x + " / " + y+ "\n";

				solution +="When 0 is being divided by another number, the answer will always be 0, except for one instance."+ "\n";
				solution +=x + " / " + y + " = 0"+ "\n";

				solution +="The only instance the answer will not be 0, is when 0 is being divided by 0, then there"+ "\n";
				solution +="will be no answer, as anything divided by 0 is undefined, or not abled to be solved."+ "\n";
			}
		}
	}
}