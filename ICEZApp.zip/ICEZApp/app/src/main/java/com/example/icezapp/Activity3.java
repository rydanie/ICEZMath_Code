package com.example.icezapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Activity3 extends AppCompatActivity {

    String s;
    ArrayList<Equation> elist;
    Button btn1, btn2, btn3, btn4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        Intent i = getIntent();
        s = i.getStringExtra("equation");

        genEquations();
        configButton();
        //TextView textViewToChange = (TextView) findViewById(R.id.confirmTxt);
        //textViewToChange.setText(s);
    }

    public void genEquations()
    {
        StringManipulator sm = new StringManipulator(s);
        elist = sm.getEquationList();

        btn1 =  (Button) findViewById(R.id.eq1);
        btn1.setText(elist.get(0).getEquation());

        btn2 =  (Button) findViewById(R.id.eq2);
        btn2.setText(elist.get(1).getEquation());

        btn3 =  (Button) findViewById(R.id.eq3);
        btn3.setText(elist.get(2).getEquation());

        btn4 =  (Button) findViewById(R.id.eq4);
        btn4.setText(elist.get(3).getEquation());
    }

    public void configButton(){
        Button return2 = (Button) findViewById(R.id.return2);
        return2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Activity3.this, MainActivity.class));
            }
        });

        Button newEq = (Button) findViewById(R.id.newEq);
        newEq.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                genEquations();
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //EquationSolver es = new EquationSolver(elist.get(0));
               // TextView textViewToChange = (TextView) findViewById(R.id.eq1View);
               // textViewToChange.setText(es.getSolution());
                Intent intent = new Intent(Activity3.this, Activity4.class);
                intent.putParcelableArrayListExtra("key", elist);
                intent.putExtra("index", 0);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //EquationSolver es = new EquationSolver(elist.get(1));
               // TextView textViewToChange = (TextView) findViewById(R.id.eq2View);
                //textViewToChange.setText(es.getSolution());
                Intent intent = new Intent(Activity3.this, Activity4.class);
                intent.putParcelableArrayListExtra("key", elist);
                intent.putExtra("index", 1);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //EquationSolver es = new EquationSolver(elist.get(2));
                //TextView textViewToChange = (TextView) findViewById(R.id.eq3View);
               // textViewToChange.setText(es.getSolution());
                Intent intent = new Intent(Activity3.this, Activity4.class);
                intent.putParcelableArrayListExtra("key", elist);
                intent.putExtra("index", 2);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //EquationSolver es = new EquationSolver(elist.get(3));
                //TextView textViewToChange = (TextView) findViewById(R.id.eq4View);
                //textViewToChange.setText(es.getSolution());
                Intent intent = new Intent(Activity3.this, Activity4.class);
                intent.putParcelableArrayListExtra("key", elist);
                intent.putExtra("index", 3);
                startActivity(intent);
            }
        });

    }
}
