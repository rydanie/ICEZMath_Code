package com.example.icezapp;

import java.util.*;
//import java.io
import java.util.Arrays;

public class StringManipulator
{
	String equation;
	int operand;
	ArrayList eList;
	ArrayList savedList;

	/**
	 * Class constructor taking in a string as a parameter
	 * @param result
	 */
	public StringManipulator(String result)
	{
		equation = result;
		eList = new ArrayList<Equation>();
		
		
		System.out.println(result);
		
		FindOperand(equation);
		GenerateEquation(operand);
		
	}

	/**
	 * Finds the operand in the string passed through the parameter and
	 * assigns the equation a preset interger value that equates to different operands
	 * @param equation
	 * @return
	 */
	public int FindOperand(String equation)
	{
		
		if (equation.contains("+"))
			operand = 1;
		else if (equation.contains("-") || equation.contains("—"))
			operand = 2;
		else if (equation.contains("*")||equation.contains("X")||equation.contains("x"))
			operand = 3;
		else if (equation.contains("/"))
			operand = 4;
		else
			operand = 0;
		
		return operand;


		
	}

	/**
	 * Genreates an arraylist of equation object based off of the type of operand
	 * @param op
	 */
	public void GenerateEquation(int op)
	{
		Random r = new Random();
		
		switch (op)
		{
		case 1:
			for(int i = 0; i < 4; i++)
			{
				int x = r.nextInt(11);
				int y = r.nextInt(11);
				String example =  x + " + " + y;
				
				System.out.println(example);
				
				Equation a = new Equation(x,y,operand,example);
				eList.add(a);
			}
			break;
		case 2:
			for(int i = 0; i < 4; i++)
			{
				int x = r.nextInt(11);
				int y = r.nextInt(11);
				String example =  x + " - " + y;
				
				System.out.println(example);
				
				Equation a = new Equation(x,y,operand,example);
				eList.add(a);
			}
			break;
		case 3:
			for(int i = 0; i < 4; i++)
			{
				int x = r.nextInt(11);
				int y = r.nextInt(11);
				String example =  x + " * " + y;
				
				System.out.println(example);
				
				Equation a = new Equation(x,y,operand,example);
				eList.add(a);
			}
			break;
		case 4:
			for(int i = 0; i < 4; i++)
			{
				int x = r.nextInt(11);
				int y = r.nextInt(11);
				String example =  x + " / " + y;
				
				System.out.println(example);
				
				Equation a = new Equation(x,y,operand,example);
				eList.add(a);
			}
			break;
		default:
			System.out.println("Operation not found please retry.");
			break;
			
		}
		
		saveEquationList(eList);
		
	}

	/**
	 * Sets the generated equation arraylist
	 * @param a
	 */
	public void saveEquationList(ArrayList a)
	{
		savedList = a;
	}

	/**
	 * Returns the generated equation arraylist
	 */
	public ArrayList<Equation> getEquationList()
	{
		return savedList;
	}

	/**
	 * Clears the generated equation arraylist
	 */
	public void clearList()
	{
		eList.clear();
	}
	

}
