package com.example.icezapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Equation implements Parcelable {
	
	int x;
	int y;
	int operand;
	String equation;

	/**
	 * Generates an equation object based on the requires inputs int, int, int, string
	 * @param a
	 * @param b
	 * @param op
	 * @param s
	 */
	public Equation(int a, int b, int op, String s)
	{
		x = a;
		y = b;
		operand = op;
		equation = s;
		
	}

	/**
	 * Parcel method used to move data from one activity to another
	 * @param in
	 */
	protected Equation(Parcel in) {
		x = in.readInt();
		y = in.readInt();
		operand = in.readInt();
		equation = in.readString();
	}

	/**
	 * Creator object which stores the object that must be passed between activities
	 */
	public static final Creator<Equation> CREATOR = new Creator<Equation>() {
		@Override
		public Equation createFromParcel(Parcel in) {
			return new Equation(in);
		}

		@Override
		public Equation[] newArray(int size) {
			return new Equation[size];
		}
	};

	/**
	 * Set int x value
	 */
	public void setx(int i)
	{
		
	}

	/**
	 * Get int x value
	 */
	public int getx()
	{
		return x;
	}

	/**
	 * Set int y value
	 */
	public void sety(int i)
	{
		x = i;
	}

	/**
	 * Get int y value
	 */
	public int gety()
	{
		return y;
	}

	/**
	 * Set int operand value
	 */
	public void setOpperand(int i)
	{
		y = i;
	}

	/**
	 * Get int operand value
	 */
	public int getOperand()
	{
		return operand;
	}

	/**
	 * Set String s value
	 */
	public void setEquation(String s)
	{
		equation = s;
	}

	/**
	 * Get String s value
	 */
	public String getEquation()
	{
		return equation;
	}

	/**
	 * Describes contents passed between activities
	 */
	@Override
	public int describeContents() {
		return 0;
	}

	/**
	 * Writes parcel data to the equation object that will be passed between activities
	 */
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(x);
		dest.writeInt(y);
		dest.writeInt(operand);
		dest.writeString(equation);
	}
}
