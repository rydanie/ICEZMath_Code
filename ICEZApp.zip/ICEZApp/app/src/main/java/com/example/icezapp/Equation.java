package com.example.icezapp;

import android.os.Parcel;
import android.os.Parcelable;

public class Equation implements Parcelable {
	
	int x;
	int y;
	int operand;
	String equation;
	
	public Equation(int a, int b, int op, String s)
	{
		x = a;
		y = b;
		operand = op;
		equation = s;
		
	}

	protected Equation(Parcel in) {
		x = in.readInt();
		y = in.readInt();
		operand = in.readInt();
		equation = in.readString();
	}

	public static final Creator<Equation> CREATOR = new Creator<Equation>() {
		@Override
		public Equation createFromParcel(Parcel in) {
			return new Equation(in);
		}

		@Override
		public Equation[] newArray(int size) {
			return new Equation[size];
		}
	};

	public void setx(int i)
	{
		
	}
	
	public int getx()
	{
		return x;
	}
	
	public void sety(int i)
	{
		x = i;
	}
	
	public int gety()
	{
		return y;
	}
	
	public void setOpperand(int i)
	{
		y = i;
	}
	
	public int getOperand()
	{
		return operand;
	}
	
	public void setEquation(String s)
	{
		equation = s;
	}
	
	public String getEquation()
	{
		return equation;
	}

	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeInt(x);
		dest.writeInt(y);
		dest.writeInt(operand);
		dest.writeString(equation);
	}
}
