package com.example.icezapp;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.navigation.fragment.NavHostFragment;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    String s;
    Random rand;
    Bitmap bitmap;
    MyTessOCR mTessOCR;
    int[] imgs;
    int i;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_main);

        configButton();
        OCR();

        //TextView textViewToChange = (TextView) findViewById(R.id.eq);
        //textViewToChange.setText(s);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public String OCR()
    {
        rand  = new Random();
        Resources res = getResources();
        // TypedArray icons = res.obtainTypedArray(R.array.image_array);
        // Drawable drawable = icons.getDrawable(rand.nextInt(icons.length()));

        imgs = new int[22];
        imgs[0] = R.drawable.x;
        imgs[1] = R.drawable.division;
        imgs[2] = R.drawable.star;
        imgs[3] = R.drawable.subtract;
        imgs[4] = R.drawable.a1;
        imgs[5] = R.drawable.ad;
        imgs[6] = R.drawable.as;
        imgs[7] = R.drawable.d;
        imgs[8] = R.drawable.fg;
        imgs[9] = R.drawable.flanokagw;
        imgs[10] = R.drawable.g;
        imgs[11] = R.drawable.gg;
        imgs[12] = R.drawable.kj;
        imgs[13] = R.drawable.mn;
        imgs[14] = R.drawable.nd;
        imgs[15] = R.drawable.ocrtest;
        imgs[16] = R.drawable.oi;
        imgs[17] = R.drawable.pc;
        imgs[18] = R.drawable.pcgentest;
        imgs[19] = R.drawable.rt;
        imgs[20] = R.drawable.ur;
        imgs[21] = R.drawable.ws;

        int i = imgs[rand.nextInt(22)];


        mTessOCR = new MyTessOCR(this, "eng");

        // Resources res = getResources();
        //Drawable drawable = res.getDrawable(R.drawable.add);
        bitmap = BitmapFactory.decodeResource(getResources(), i );
        s = mTessOCR.getOCRResult(bitmap);

        ImageView camera = (ImageView) findViewById(R.id.eqImage);
        camera.setImageResource(i);
        return s;
    }
    public void configButton(){
        Button start = (Button) findViewById(R.id.start);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent i = new Intent(MainActivity.this, Activity2.class);
               i.putExtra("equation", s);
                startActivity(i);
            }
        });

        Button newImage = (Button) findViewById(R.id.newImage);
        newImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OCR();
            }
        });
    }
}