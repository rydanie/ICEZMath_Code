package com.example.icezapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class Activity4 extends AppCompatActivity {

    ArrayList<Equation> elist;
    Equation e;
    int index;

    /**
     * Defines what will diplay on the screen when the activity is created based on the data provided by the previous activity
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);

        elist = getIntent().getParcelableArrayListExtra("key");
        index = getIntent().getIntExtra("index", 0);

        e = elist.get(index);
        EquationSolver es = new EquationSolver(e);
        TextView textViewToChange = (TextView) findViewById(R.id.eqFinalView);
        textViewToChange.setText(es.getSolution());

        configButton();
    }

    /**
     * Creates and defines the actions of button contained in the Activity3 view when they are clicked
     */
    public void configButton(){
        Button return3 = (Button) findViewById(R.id.return3);
        return3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Activity4.this, Activity3.class);
                i.putExtra("equation", e.equation );
                startActivity(i);
            }
        });


    }
}
