package com.example.icezapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    String s;

    /**
     * Defines what will diplay on the screen after the user takes a picture of a math problem
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        configButton();

        Intent i = getIntent();
        s = i.getStringExtra("equation");
        TextView textViewToChange = (TextView) findViewById(R.id.confirmTxt);
        textViewToChange.setText(s);
    }

    /**
     * Creates and defines the actions of button contained in the Activity2 view when they are clicked
     */
    public void configButton(){
        Button return1 = (Button) findViewById(R.id.return1);
        return1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Activity2.this, MainActivity.class));
            }
        });

        Button yes = (Button) findViewById(R.id.yes);
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              if(!s.contains("-")
                      && !s.contains("+")
                      && !s.contains("/")
                      && !s.contains("x")
                      && !s.contains("X")
                      && !s.contains("*")
                      && !s.contains("——"))  {

                  TextView textViewToChange = (TextView) findViewById(R.id.warningView);
                  textViewToChange.setText("Sorry, unable to procede as the we could not find an operand in the picture.");

              } else {
                  Intent i = new Intent(Activity2.this, Activity3.class);
                  i.putExtra("equation", s);
                  startActivity(i);
              }
            }
        });
    }
}
